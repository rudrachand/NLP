df <- read.csv("data/harry.csv", stringsAsFactors = FALSE)
ref_id <- "1140"
df[df$id == ref_id,]


